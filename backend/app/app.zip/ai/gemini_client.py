import json
import urllib.request
from tenacity import retry, stop_after_attempt, wait_exponential

# Define robust retry logic: wait 2^x * 1 second between each retry, up to 10 seconds, max 4 attempts
@retry(stop=stop_after_attempt(4), wait=wait_exponential(multiplier=1, min=2, max=10))
def call_gemini(prompt: str, expect_json: bool = True, model_name: str = "qwen2.5-coder:7b") -> str:
    """
    Robust centralized client to call the Local Ollama API (replacing Gemini).
    Handles retries, exponential backoff, and JSON structuring.
    """
    url = 'http://localhost:11434/api/generate'
    
    # We ignore the passed model_name if it is still gemini, hardcode to the local model.
    if "gemini" in model_name.lower() or model_name == "default":
        model_name = "qwen2.5-coder:7b"
        
    data = {
        'model': model_name,
        'prompt': prompt,
        'stream': False
    }
    
    # Passing format: "json" ensures Ollama returns valid JSON
    if expect_json:
        data['format'] = 'json'

    req = urllib.request.Request(url, data=json.dumps(data).encode('utf-8'), headers={'Content-Type': 'application/json'})

    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result.get('response', '')
    except Exception as e:
        print(f"Ollama API Exception: {e}")
        raise e

def call_gemini_json(prompt: str, model_name: str = "qwen2.5-coder:7b") -> dict:
    """
    Calls Ollama API and safely parses the JSON response.
    """
    response_text = call_gemini(prompt, expect_json=True, model_name=model_name)
    try:
        # Sometimes LLMs wrap JSON in markdown blocks even with format set
        clean_json = response_text.strip()
        if clean_json.startswith("```json"):
            clean_json = clean_json[7:]
        if clean_json.endswith("```"):
            clean_json = clean_json[:-3]
        clean_json = clean_json.strip()
        
        return json.loads(clean_json)
    except json.JSONDecodeError as e:
        print(f"JSON Parsing Error: {e} | Raw Response: {response_text}")
        raise ValueError(f"Failed to parse JSON from Ollama: {e}")
