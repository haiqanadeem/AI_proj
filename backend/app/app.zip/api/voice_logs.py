from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from app.database.connection import get_db
from app.models.user import User
from app.models.voice_log import VoiceLog
from app.services.auth_service import get_current_user

router = APIRouter(prefix="/voice-logs", tags=["voice_logs"])

class VoiceLogCreate(BaseModel):
    command: str
    intent_detected: Optional[str] = None
    confidence_score: Optional[float] = None
    execution_time_ms: Optional[int] = None

class VoiceLogResponse(BaseModel):
    id: int
    user_id: int
    command: str
    intent_detected: Optional[str]
    confidence_score: Optional[float]
    execution_time_ms: Optional[int]
    timestamp: datetime

    class Config:
        from_attributes = True

@router.post("", response_model=VoiceLogResponse, status_code=201)
def create_voice_log(
    req: VoiceLogCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    try:
        log_entry = VoiceLog(
            user_id=current_user.id,
            command=req.command,
            intent_detected=req.intent_detected,
            confidence_score=req.confidence_score,
            execution_time_ms=req.execution_time_ms
        )
        db.add(log_entry)
        db.commit()
        db.refresh(log_entry)
        return log_entry
    except Exception as e:
        print(f"Failed to create voice log: {e}")
        raise HTTPException(status_code=500, detail="Failed to save voice log.")

@router.get("", response_model=List[VoiceLogResponse])
def get_user_voice_logs(
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    logs = db.query(VoiceLog).filter(VoiceLog.user_id == current_user.id).order_by(VoiceLog.timestamp.desc()).limit(limit).all()
    return logs
